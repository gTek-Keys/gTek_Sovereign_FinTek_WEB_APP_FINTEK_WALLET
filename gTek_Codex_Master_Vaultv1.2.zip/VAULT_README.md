# gTek Sovereign Codex Vault Configuration

This vault contains all environmental variables and secret keys required for full decentralized deployment and interaction.

## How to Use
1. Duplicate `.env.example` as `.env`
2. Populate with real API keys and values
3. Secure `.env` in your vault; do not expose it publicly

## Secrets Overview
- IPFS Storage (NFT.Storage, Web3.Storage)
- Vercel for frontend deployments
- ArDrive Wallet for Arweave storage
- Ethereum Network Providers (Infura, Alchemy, etc.)
- Gnosis Safe Treasury Access
- DAO Governance + Reward Token Configuration

🔐 Mobbin’ Eternal. Secured by Tok Sovereign Chat System.
