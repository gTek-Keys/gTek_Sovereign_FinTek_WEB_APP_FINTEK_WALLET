# Vault Instructions

This directory contains secure references for managing environment variables.

- `.env.sample` is a template.
- `env.cipher` is the encrypted real key store.
- Use `generate_env.sh` to decrypt.

Security Protocol: AES-256 or GPG. Do not commit `.env` or `env.cipher` to public repos.
