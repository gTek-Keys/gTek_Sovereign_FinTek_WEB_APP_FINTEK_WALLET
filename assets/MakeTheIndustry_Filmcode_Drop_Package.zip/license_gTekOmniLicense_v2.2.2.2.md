# gTek OmniLicense v2.2.2.2
All rights reserved under sovereign codex authority.